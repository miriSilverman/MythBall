﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMovement : MonoBehaviour
{

    [SerializeField] private GameObject room;

    [SerializeField] private float rotationAngle;

    // void Update()
    // {
    //     if (room.transform.rotation.x < rotationAngle)
    //     {
    //         Vector3 pos = transform.position;
    //              
    //     }
    // }
}
